﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _100802ksm
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int hotel = 0;
            int a = 0;
            int b = 0;
            
            

            if (comboBox1.Text == "")
            {
                MessageBox.Show("숙박 기간을 선택하시오");
                return;
            }
            if (radioButton1.Checked == true)
            {
                //롯데호텔이 선택 되어있는 경우
                hotel = 500000;
            }
            else
            {
                if (radioButton2.Checked == true)
                {
                    //조선비치
                    hotel = 450000;
                }
                else
                {
                    if (radioButton3.Checked == true)
                    {
                        //신라스테이
                        hotel = 200000;
                    }
                    else
                    {
                        if (radioButton4.Checked == true)
                        {
                            //힐튼
                            hotel = 350000;
                        }
                        else
                        {
                            //모텔
                            hotel = 100000;
                        }
                    }
                }
            }
                if (comboBox1.Text == "1박2일")
                {
                    a = 1;
                }
                else
                {
                    if (comboBox1.Text == "2박3일")
                    {
                        a = 2;
                    }
                    else
                    {
                        if (comboBox1.Text == "3박4일")
                        {
                            a = 3;
                        }
                        else
                        {
                            if (comboBox1.Text == "4박5일")
                            {
                                a = 4;
                            }
                            else
                            {
                                a = 5;
                            }
                        }
                    }
                }
                b = hotel * a;
            textBox1.Text = b.ToString();
        }
    }
}
