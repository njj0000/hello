﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _100801ksm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a = 0; // 키
            double b = 0; // 몸무게
            double c = 0; // 표준몸무게   
            double d = 0; // 비만도


            a = double.Parse(textBox1.Text);
            b = double.Parse(textBox2.Text);
            

            if (a >= 160)
            {
                c = (a - 100) * 0.9;
            }
            else
            {
                if (a >= 150)
                {
                    c = (a - 150) / 2 + 50;
                }
                else
                {
                    c = (a - 100);
                }
            }
            textBox3.Text = c.ToString();

            d = (b - c) * 100 / c;
            textBox4.Text = d.ToString();
           
            if(d>20)
            {
                textBox5.Text = "비만";
            }
            else
            {
                if(d>=10)
                {
                    textBox5.Text = "과체중";
                }
                else
                {
                    textBox5.Text = "정상";
                }
            }
        }
        

    }
}
